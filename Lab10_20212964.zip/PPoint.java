/**
    @author Kim Dongjin
*/
package kr.ac.kookmin.cs;
/**
    read x and y
*/
public class PPoint {
    int xA;
    int yA;
    /**
        The basic constructor that allocates xA and xY
    */
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    /**
        get xA
    */
    public int getX() {
        return xA;
    }
    /**
        get yA
    */
    public int getY() {
        return yA;
    }
}
