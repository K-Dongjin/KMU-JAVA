/**
    @author Kim Dongjin
*/
import kr.ac.kookmin.cs.*;
/**
    print value of xA and xY
*/
class PPointTest {
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
